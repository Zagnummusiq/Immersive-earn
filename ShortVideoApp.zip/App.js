
import React from 'react';
import HomeScreen from './src/screens/HomeScreen';
import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';

export default function App() {
  return (
      <View style={{flex: 1}}>
            <StatusBar style="light" />
                  <HomeScreen />
                      </View>
                        );
                        }
                        