
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Video } from 'expo-av';

export default function HomeScreen() {
  const [earnings, setEarnings] = useState(0);
    const videoUrl = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

      const addEarnings = () => {
          setEarnings(prev => prev + 0.002);
            };

              return (
                  <View style={styles.container}>
                        <Text style={styles.earnings}>Earnings: ${earnings.toFixed(3)}</Text>

                                    <Video
                                            source={{ uri: videoUrl }}
                                                    style={styles.video}
                                                            useNativeControls
                                                                    resizeMode="cover"
                                                                            onPlaybackStatusUpdate={(status) => {
                                                                                      if (status.didJustFinish) addEarnings();
                                                                                              }}
                                                                                                    />

                                                                                                                <TouchableOpacity style={styles.button} onPress={addEarnings}>
                                                                                                                        <Text style={styles.buttonText}>Watch & Earn</Text>
                                                                                                                              </TouchableOpacity>
                                                                                                                                  </View>
                                                                                                                                    );
                                                                                                                                    }

                                                                                                                                    const styles = StyleSheet.create({
                                                                                                                                      container: { flex: 1, backgroundColor: 'black', padding: 20 },
                                                                                                                                        earnings: { color: 'gold', fontSize: 20, textAlign: 'center', margin: 20 },
                                                                                                                                          video: { width: '100%', height: 300, marginVertical: 20 },
                                                                                                                                            button: { backgroundColor: 'gold', padding: 15, borderRadius: 10 },
                                                                                                                                              buttonText: { color: 'black', textAlign: 'center', fontWeight: 'bold' }
                                                                                                                                              });
                                                                                                                                              