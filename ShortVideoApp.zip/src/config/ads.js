
export const AD_CONFIG = {
  adUnits: {
      banner: 'ca-app-pub-5364085805702549/7398215380',
          interstitial: 'ca-app-pub-5364085805702549/7395073276',
              rewarded: 'ca-app-pub-5364085805702549/2674187497',
                  native: 'ca-app-pub-5364085805702549/4195809265'
                    },
                      directLinks: [
                          'https://otieu.com/4/8348809',
                              'https://otieu.com/4/913',
                                  'https://otieu.com/4/96106975943',
                                      'https://otieu.com/4/9022048',
                                          'https://otieu.com/4/9611854'
                                            ],
                                              earnings: {
                                                  perVideo: 0.002,
                                                      perAd: 0.015,
                                                          dailyCap: 5.00
                                                            }
                                                            };
                                                            